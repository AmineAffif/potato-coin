FactoryBot.define do
  factory :potato_price do
    time { "2025-01-31 17:08:42" }
    value { 1.5 }
  end
end
